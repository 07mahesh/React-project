import React from 'react';
import { BarChart3, Users, Clock, CheckCircle2 } from 'lucide-react';

const stats = [
  { name: 'Active Projects', value: '12', icon: BarChart3 },
  { name: 'Team Members', value: '24', icon: Users },
  { name: 'Hours Logged', value: '160', icon: Clock },
  { name: 'Tasks Completed', value: '38', icon: CheckCircle2 },
];

export function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
        <p className="mt-2 text-sm text-gray-600">
          Welcome back! Here's an overview of your project metrics.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <div
            key={stat.name}
            className="overflow-hidden rounded-lg bg-white px-4 py-5 shadow sm:p-6"
          >
            <dt className="truncate text-sm font-medium text-gray-500 flex items-center gap-2">
              <stat.icon className="h-5 w-5 text-gray-400" />
              {stat.name}
            </dt>
            <dd className="mt-1 text-3xl font-semibold tracking-tight text-gray-900">
              {stat.value}
            </dd>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-lg bg-white shadow">
          <div className="p-6">
            <h2 className="text-base font-semibold text-gray-900">
              Recent Projects
            </h2>
            <div className="mt-6 flow-root">
              <div className="overflow-x-auto">
                <div className="inline-block min-w-full align-middle">
                  <table className="min-w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                          Project
                        </th>
                        <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                          Status
                        </th>
                        <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                          Progress
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white">
                      {[
                        { name: 'Website Redesign', status: 'In Progress', progress: '60%' },
                        { name: 'Mobile App', status: 'Planning', progress: '20%' },
                        { name: 'Marketing Campaign', status: 'Completed', progress: '100%' },
                      ].map((project, idx) => (
                        <tr key={project.name} className={idx !== 2 ? 'border-b border-gray-200' : undefined}>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-900">
                            {project.name}
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            {project.status}
                          </td>
                          <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                            {project.progress}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-lg bg-white shadow">
          <div className="p-6">
            <h2 className="text-base font-semibold text-gray-900">
              Upcoming Tasks
            </h2>
            <div className="mt-6 flow-root">
              <ul role="list" className="divide-y divide-gray-200">
                {[
                  { name: 'Design Review', due: 'Today', priority: 'High' },
                  { name: 'Client Meeting', due: 'Tomorrow', priority: 'Medium' },
                  { name: 'Project Planning', due: 'Next Week', priority: 'Low' },
                ].map((task) => (
                  <li key={task.name} className="py-4">
                    <div className="flex items-center space-x-4">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-gray-900">
                          {task.name}
                        </p>
                        <p className="truncate text-sm text-gray-500">
                          Due: {task.due}
                        </p>
                      </div>
                      <div>
                        <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium text-gray-900 bg-gray-100">
                          {task.priority}
                        </span>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}