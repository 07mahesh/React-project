import React from 'react';

export function Projects() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">Projects</h1>
    </div>
  );
}