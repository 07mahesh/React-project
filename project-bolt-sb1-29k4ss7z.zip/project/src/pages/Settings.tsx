import React from 'react';

export function Settings() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">Settings</h1>
    </div>
  );
}