import React from 'react';

export function Tasks() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">Tasks</h1>
    </div>
  );
}