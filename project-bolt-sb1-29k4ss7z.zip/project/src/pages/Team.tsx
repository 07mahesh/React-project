import React from 'react';

export function Team() {
  return (
    <div>
      <h1 className="text-2xl font-semibold text-gray-900">Team</h1>
    </div>
  );
}